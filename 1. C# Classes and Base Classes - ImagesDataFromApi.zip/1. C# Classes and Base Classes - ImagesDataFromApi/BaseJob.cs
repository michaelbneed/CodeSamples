﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using Adis.Batch.Domain.Constants;
using Adis.Batch.Shared;
using Adis.QueueMessage.Messages;
using Asl.Data;
using Asl.Data.Models;
using log4net;
using Newtonsoft.Json;

namespace Adis.Batch.Domain.JobHandler
{
    // This is a base class and will not be instantiated, do not change the modifier
    public abstract class BaseJob<TMessageType> : IJob where TMessageType : JobMessage
    {
        private readonly string _message;
        private readonly bool _isLogged;

        protected IModelRepository ModelRepository;
        protected readonly ILog Log;
        protected TMessageType JobMessage;
        protected List<int> AssignmentIdList;
        protected string FileName;

        protected readonly Guid SystemUserId = new Guid(ConfigurationManager.AppSettings["SystemUserId"]);

        protected BaseJob(IModelRepository modelRepository, string message, bool isLogged = false)
        {
            ModelRepository = modelRepository;
            Log = LogManager.GetLogger(GetType());
            _message = message;
            JobMessage = JsonConvert.DeserializeObject<TMessageType>(message, new JsonSerializerSettings() { MissingMemberHandling = MissingMemberHandling.Ignore });
            _isLogged = isLogged;
            AssignmentIdList = new List<int>();
            FileName = null;
        }

        // This is the heart of the class
        public async Task ProcessJob()
        {
            
            await Task.Run(() =>
            {
                var status = JobReturnStatus.Failed;
                try
                {
                    status = RunJob();
                }
                catch (DbUpdateException exception)
                {
                    Log.Error(exception);
                    throw new JobException("Sql Exception", exception);
                }
                catch (Exception ex)
                {
                    Log.Error(ex);
                    throw;
                }
                finally
                {
                    try
                    {
                        LogJob(JobReturnStatus.Success == status ? JobStatus.Keys.Success : JobStatus.Keys.Failed);
                    }
                    catch (DbUpdateException exception)
                    {
                        throw new JobException("Sql Exception", exception);
                    }
                }
            });
        }

        protected abstract JobReturnStatus RunJob();

        // Log jobs, save to system, audit trail
        private void LogJob(Guid statusGuid, bool error = false)
        {
            try
            {
                if (!_isLogged) return;
                var processedJob = new Job()
                {
                    MessageContent = _message,
                    JobStatusGuid = statusGuid,
                    JobTypeGuid = JobType.LookUp.GetJobTypeId(JobMessage.JobId),
                    FileName = FileName,
                    CreateUserId = JobMessage.UserGuid ?? SystemUserId,
                    CreateDate = DateTime.Now
                };
                ModelRepository.Add(processedJob);
                ModelRepository.SaveChanges();

                if (!AssignmentIdList.Any()) return;
                foreach (var jobDetail in AssignmentIdList.Select(assignId => new JobDetail()
                {
                    JobId = processedJob.JobId,
                    AssignmentId = assignId,
                    CreateUserId = JobMessage.UserGuid ?? SystemUserId,
                    CreateDate = DateTime.Now
                }))
                {
                    ModelRepository.Add(jobDetail);
                }
                ModelRepository.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                if (!error)
                {
                    ModelRepository.ClearUnsavedChanges();
                    LogJob(statusGuid, true);
                }
                else
                {
                    throw;
                }
            }

        }
    }
}
