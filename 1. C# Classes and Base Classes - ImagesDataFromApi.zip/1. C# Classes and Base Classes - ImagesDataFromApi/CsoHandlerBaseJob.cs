﻿using System;
using System.Configuration;
using System.Linq;
using Adis.QueueMessage.Messages;
using Asl.Data;

namespace Adis.Batch.Domain.JobHandler
{
    // This is a base class and will not be instantiated, do not change the modifier
    public abstract class CsoHandlerBaseJob<TMessageType> : BaseJob<TMessageType> where TMessageType : CsoHandlerMessage
    {
        protected Guid CsoUserId;

        protected CsoHandlerBaseJob(IModelRepository modelRepository, string message, bool isLogged = false)
            :base(modelRepository, message, isLogged)
        {
            CsoUserId = new Guid(ConfigurationManager.AppSettings["CsoUserId"]);
        }

        public bool IsAssignmentInFusion()
        {
            return GetCsoData() != null;
        }

        public CsoCachedData GetCsoData()
        {
            // Check if cso data was cached
            // Get data from DB and strore it in cache to future reference
            CsoCachedData result = CacheDataHelper.GetCachedCsoData(JobMessage);

            if (result == null || result.AssignTargetId == null || result.AssignmentId == null)
            {

                int assignmentId = LookupAssignmentId();
                int AssignTargetId = LookupAssignTargetId();
                if (assignmentId > 0 && AssignTargetId > 0)
                {
                    CsoCachedData csoCachedData = new CsoCachedData();
                    csoCachedData.AssignmentId = assignmentId;
                    csoCachedData.AssignTargetId = AssignTargetId;
                    CacheDataHelper.AddCsoDataToCache(JobMessage, csoCachedData);
                    return csoCachedData;
                }
            }
            return result;
        }

        // Get the AssignmentId - this will be used by many derived classes
        private int LookupAssignmentId()
        {
            try
            {
                string execFunc = String.Format("SELECT [ASSIGN].[GetAssignmentIdByInventoryId]('{0}','{1}')",
                    JobMessage.InventoryId, JobMessage.DepartmentGuid);
                int? result = ModelRepository.ModelDbContext().Database.SqlQuery<int>(execFunc).Single();
                return result ?? 0;
            }
            catch (Exception ex)
            {
                Log.Error("Error Executing LookupAssignmentIdByInventoryId: ", ex);
                return 0;
            }
        }

        // Get the AssignTargetId which has more specific data about products
        private int LookupAssignTargetId()
       {
            try
            {
                string execFunc = String.Format("SELECT [ASSIGN].[GetAssignTargetIdByInventoryId]('{0}','{1}')",
                    JobMessage.InventoryId, JobMessage.DepartmentGuid);
                int? result = ModelRepository.ModelDbContext().Database.SqlQuery<int>(execFunc).Single();
                return result ?? 0;
            }
            catch (Exception ex)
            {
                Log.Error("Error Executing LookupAssignTargetIdByInventoryId: ", ex);
                return 0;
            }
        }
    }
}
