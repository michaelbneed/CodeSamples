﻿/*
 * This class and code are dedicated to a solution where images from multiple systems are to be stored in Azure queue for fast data retrieval.
 * We to see if images' URL's reside in our own database by an assignId. If they don't exist we get them from the queue the store them in a database for a seperate ASP.NET MVC web app so it can display them, and other pertinent data.
 * We will be supplying a username and password to a service to get a token.
 * We will cache the token if none exists.
 * Will will access images from the web service (HTTP web api), we will incorporate json to pass data to the listener.
 * Once we retrieve the data we will save the images' URL's on the external service to our own database that supplies data to our own web app.
 * We are not storing actual BLOB data, only URL's and assoc data.
 * */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;
using Adis.QueueMessage.Messages;
using Asl.Data;
using Asl.Data.Models;
using Newtonsoft.Json;
using Adis.Batch.Domain.Constants;
using Adis.QueueMessage.Interface;
using Adis.Cache;
using Adis.Contracts.ConditionReport.Data;

namespace Adis.Batch.Domain.JobHandler
{
    public class ImageHandlerJob : CsoHandlerBaseJob<ImageHandlerMessage>
    {
        // We will pushing a Cr Message through the system to inform external systems of our tasks
        private readonly IPushCrMessageHandler _pushCrMessageHandler;

        // Credentials to authenticate to get a token and actual token related settings stored in config
        private static readonly string DmmUsername = Asl.Configuration.ConfigurationManager.GetSetting("DMMAccountUsername");
        private static readonly string DmmPassword = Asl.Configuration.ConfigurationManager.GetSetting("DMMAccountPassword");
        private readonly string _tokenUrl = Asl.Configuration.ConfigurationManager.GetSetting("DMMTokenService");
        private readonly string _imageService = Asl.Configuration.ConfigurationManager.GetSetting("DMMImageService");
        private readonly string _urlParameters = "?username=" + DmmUsername + "&password=" + DmmPassword + "&privateLabelId=1&et=true";

        // The class constructor
        public ImageHandlerJob(IModelRepository modelRepository, IPushCrMessageHandler pushCrMessageHandler, string message, bool isLogged)
            : base(modelRepository, message, isLogged)
        {
            _pushCrMessageHandler = pushCrMessageHandler;
        }

        protected override JobReturnStatus RunJob()
        {
            //Give the implementation here.
            PullImages();
            // Will need to add in return for logging purpose
            return JobReturnStatus.Success;
        }

        private void PullImages()
        {
            // This accomplishes getting the assignment id and verifying this is not already in the system, if it is we don't need it
            // GetCsoData resides in base class so it's return data is available to all derived classes, especially assignId (critical unique identifier)
            var assignId = GetCsoData();

            if (assignId != null)
            {

                Log.InfoFormat("This assignment ID is in the system");

                try
                {
                    // Add assignment Id to list for logging purpose in Job_Detail
                    if (assignId.AssignmentId != null)
                    {
                        AssignmentIdList.Add((int)assignId.AssignmentId);
                        var assign = (from a in ModelRepository.Fetch<Assignment>()
                            join ast in ModelRepository.Fetch<AssignmentTarget>() on a.AssignmentId equals ast.AssignmentId
                            join tar in ModelRepository.Fetch<Target>() on ast.TargetId equals tar.TargetId
                            where tar.SerialNumber == JobMessage.SID
                                  && a.AssignmentId == assignId.AssignmentId
                            select new
                            {
                                a.AssignmentId,
                                ast.AssignmentTargetId,
                                ast.TargetId,
                                tar.SerialNumber,

                            }).FirstOrDefault();

                        // Get and also cache the Authentication Token with method call
                        var dmmAuthResponse = GetDmmData();

                        if (dmmAuthResponse.token != null)
                        {
                            Log.InfoFormat("A token was retrieved");
                        }

                        // Get data from DMM webservice - receive and save data 
                        if (assign != null)
                        {
                            RetreiveAndSaveImages(assign.AssignmentTargetId, assign.AssignmentId, dmmAuthResponse.token);
                            PushCrMessage(assign.AssignmentId, CsoUserId);
                            //Notify Workflow about UVIS transmission for DMM
                            NotifyWorkflow(assign.AssignmentId, CsoUserId);
                        }
                        else
                        {
                            Log.ErrorFormat("No Inspection could be found for SID: {0}", JobMessage.SID);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("There was an issue with SID: {0}, Error:  {1}", JobMessage.SID, ex);
                }
            }
        }

        // Get images from service and save to database
        private void RetreiveAndSaveImages(int assignmentTargetId, int assigmentId, string token)
        {
            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(_imageService);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add("X-Openlane-Authentication", token);
                httpWebRequest.Accept = "application/json";

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    var jsonMsg = "{\"SID\":\"" + JobMessage.SID + "\"," +
                                  "\"ProductId\":\"" + JobMessage.OpenLaneProductId + "\"}";


                    streamWriter.Write(jsonMsg);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var responseStream = httpWebRequest.GetResponse().GetResponseStream();
                if (responseStream == null) return;
                using (var streamReader = new StreamReader(responseStream))
                {
                    var result = streamReader.ReadToEnd();

                    if (result == "{\"status\":\"INTERNAL_SERVER_ERROR\",\"message\":\"Error while getting Product images \",\"throwable\":null}")
                    {
                        Log.InfoFormat("The service request was not null but there was a problem with the request or data");
                    }
                    else
                    {
                        Log.InfoFormat("The processor successfully received Image URL's and related data from Open Lane for SID:{0}", JobMessage.SID);
                    }

                    var doc = JsonConvert.DeserializeXmlNode(result, "Root");

                    // Get XML Doc Images node 
                    const string xpath = "Root/Images";
                    var nodes = doc.SelectNodes(xpath);

                    // Get access to single nodes 
                    // Start by assigning the Root node
                    const string xPathRoot = "Root";
                    var rootNode = doc.SelectSingleNode(xPathRoot);

                    // Store the pakage node 
                    const string packageXpath = "Root/Images/packageTierId";
                    var packageNode = doc.SelectSingleNode(packageXpath);

                    // Conditions appled to the storage of the package
                    var packageId = packageNode != null && packageNode.InnerText != string.Empty ? Convert.ToInt32(packageNode.InnerText) : 1;

                    // this var to store the ID and the Name
                    var package = (from pkg in ModelRepository.Fetch<PackageTierLk>()
                        where pkg.PackageTierId == packageId
                        select new
                        {
                            pkg.PackageTierId,
                            pkg.Name
                        }).FirstOrDefault();

                    // Remove old data if there is data matching this AssignmentId
                    var existingAssignmentInAttachments =
                        (from ast in ModelRepository.Fetch<AssignmentTargetAttachment>()
                            join at in ModelRepository.Fetch<AssignmentTarget>() on ast.AssignmentTargetId equals
                                at.AssignmentTargetId
                            join aa in ModelRepository.Fetch<Assignment>() on at.AssignmentId equals aa.AssignmentId
                            where (aa.AssignmentId == assigmentId
                                   && ast.AttachmentTypeId == AttachmentType.Keys.ReconImage)
                            select ast);

                    foreach (var existingAssign in existingAssignmentInAttachments)
                    {
                        ModelRepository.Remove(existingAssign);
                    }

                    // Loop through xml data and get the image url's and other requested data
                    if (nodes != null)
                    {
                        foreach (var assignAttachment in from XmlNode childNode in nodes
                            let imageUrl = package != null && package.Name == CacheNameConstants.HighDefResolution ? childNode["hrFileName"] != null
                                ? childNode["hrFileName"].InnerXml : string.Empty : childNode["regularUrl"] != null
                                    ? childNode["regularUrl"].InnerXml : string.Empty
                            select new AssignmentTargetAttachment
                            {
                                // All fields being queried from data / model / service
                                AssignmentTargetId = assignmentTargetId,
                                AttachmentTypeId = AttachmentType.Keys.ReconImage,
                                HhChangeLocaltime = DateTime.Now,
                                CreateDate = DateTime.Now,
                                CreateUserId = SystemUserId,
                                AttachmentStatusId = AttachmentStatus.Keys.Ready,
                                FileName = imageUrl,
                                OpenLaneProductId = rootNode != null && rootNode["ProductId"] != null ? Convert.ToInt32(rootNode["ProductId"].InnerXml) : 0,
                                ThumbnailImageUrl = childNode["thumbnailUrl"] != null ? childNode["thumbnailUrl"].InnerXml : string.Empty,
                                PackageTierId = childNode["packageTierId"] != null && childNode["packageTierId"].InnerXml != string.Empty ? Convert.ToInt32(childNode["packageTierId"].InnerXml) : 0,
                                ImageUrl = imageUrl,
                                ImageCaption = childNode["imageCaption"] != null ? childNode["imageCaption"].InnerXml : string.Empty,
                                ImageOrder = childNode["imageOrder"] != null ? Convert.ToInt32(childNode["imageOrder"].InnerXml) : 0
                            })
                        {
                            // System.Diagnostics.Debug.WriteLine(childreNode.InnerXml); 
                            // Only uncomment the above line for testing
                            // Add data to model repo
                            ModelRepository.Add(assignAttachment);
                        }
                        // Save the image url's and other data from model repo to our internal system
                        ModelRepository.SaveChanges();
                    }
                    else
                    {
                        Log.ErrorFormat("No Images were uploaded for SID: {0},",
                            JobMessage.SID);
                    }
                }
            }
            catch (WebException wex)
            {
                var response = wex.Response as HttpWebResponse;
                
                // Handle issues where the http / api returns an error 401, 404
                if ((response != null) &&
                        response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    Log.Error("There was a web exception Error for the authentication token, invalid data is the result:", wex);

                    // Clear the token and refresh it, retry getting data
                    var getToken = GetAuthenticationToken(_tokenUrl + _urlParameters);
                    token = getToken.token;
                    RetreiveAndSaveImages(assignmentTargetId, assigmentId, token);
                }
                // It isn't working, and the api might have issues
                else
                    throw;
            }
            catch (Exception ex)
            {
                Log.Error("There was an error retrieving SID or images", ex);
                throw;
            }
        }

        private void PushCrMessage(int assignmentId, Guid userId)
        {
            try
            {
                // Push CR Message 
                _pushCrMessageHandler.AddPushCrMessage(assignmentId, userId, new List<string>{EventTypeKeys.ReconUpdateEvent});
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        private void NotifyWorkflow(int assignmentId, Guid userId)
        {
            try
            {
                var wfservice = ServiceHelper.GetInspectionWorkflowServiceClient();
                wfservice.SendFinalUvisTransmission(assignmentId, userId);
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
        }

        // DMM Authentication logic
        private DMMAuthServiceResponse GetDmmData()
        {
            var dmmAuthResponse = CacheDataHelper.GetCachedDmmAuthServiceResponse();

            // If there is no cached Authentication token in redis cache get a token and cache it
            if (dmmAuthResponse != null) return dmmAuthResponse;
            dmmAuthResponse = GetAuthenticationToken(_tokenUrl + _urlParameters);

            if (!string.IsNullOrEmpty(dmmAuthResponse.token))
            {
                // Cache our token
                CacheDataHelper.AddDmmAuthServiceResponseToCache(dmmAuthResponse);
            }
            return dmmAuthResponse;
        }


        // DMM Auth token
        private DMMAuthServiceResponse GetAuthenticationToken(string url)
        {
            // Synchronous Consumption
            var syncClient = new WebClient();
            var content = syncClient.DownloadString(url);

            // Create the Json serializer and parse the response
            var serializer = new DataContractJsonSerializer(typeof(DMMAuthServiceResponse));
            using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(content)))
            {
                var data = (DMMAuthServiceResponse)serializer.ReadObject(ms);
                return data;
            }
        }
    }
}
