This set of files supports getting data from a web API.

The data is retieved and saved to a DB. 

This code works works with the Azure queue.

There are PDF's printed for your convenience.

C#
LINQ
EF