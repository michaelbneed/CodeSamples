This is simple JS to get a device location/web browser location.

If you open the map HTML file it just works!

Try it in Chrome.