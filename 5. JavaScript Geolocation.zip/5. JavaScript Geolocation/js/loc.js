// JavaScript source code
var geocoder;

if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(successFunction, errorFunction);
}
//Get the device coordinates;
function successFunction(position) {
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;
    codeLatLng(lat, lng);

}

function errorFunction(){
    alert("Geocoder failed" + status);
}

function initialize() {
    geocoder = new google.maps.Geocoder();
}

function codeLatLng(lat, lng) {

    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({ 'latLng': latlng }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            console.log(results)
            if (results[1]) {
                //get full address
                alert(results[0].formatted_address)
                //country
                for (var i = 0; i < results[0].address_components.length; i++) {
                    for (var b = 0; b < results[0].address_components[i].types.length; b++) {

                        //in the json return the "locality" field holds the city data
                        if (results[0].address_components[i].types[b] == "locality") {
                            //assign the data 
                            city = results[0].address_components[i];
                            break;
                        }
                    }
                    
                }
                //alert(city.short_name + " " + city.long_name)
                alert("You are in the city of" + " " + city.long_name)
                var city = city.long_name;
				document.getElementById("locTextArea").innerHTML = "You have been detected in the city of " + city;
				
				// ok we got the city successfully so we must be ablr to geolocate.... so use the coordinates and fetch the map
				initMap(lat, lng);

				// Hard coded a condition since when I am making this there will only ever be 3 specific locations we care about. 
                // If list of IN cities is to grow this should be more dynamic.
                if (city === "Indianapolis") {
				    document.getElementById("myLink").href = "http://www.michaelneed.com";
				}
				else if
					(city === "Columbus") {
					document.getElementById("myLink").href = "http://www.michaelneed.com";
					}
				else if
					(city === "Greenwood") {
					document.getElementById("myLink").href = "http://www.michaelneed.com";
					}
				else
					document.getElementById("myLink").href = "http://www.michaelneed.com";
					

            } else {
                alert("Nothing returned...");
            }
        } else {
            alert("Failure: " + status);
        }
        
    });
    
}

function initMap(lat, lng) {

        var latlng = new google.maps.LatLng(lat, lng);
		
		var coordin = document.getElementById("coordTextArea").innerHTML = latlng;
		
		 //assign the map to the HTML div element called 'map' 
		var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat, lng},
          zoom: 13
		  
		});
} 