﻿using System.Collections.Generic;
using System.Linq;
using BankApp.Transaction;

namespace BankApp.Account
{
    public class Account : AccountTypes
    {
        public int AccountId { get; set; }
        public decimal StartingBalance { get; set; }
        public decimal NewBalance { get; set; }
        public decimal OldBalance { get; set; }
        public decimal DisplayBalance { get; set; }
        private TransactionLegder Ledger { get; set; }
        public bool SuccessfulTransaction { get; set; }
        public string TransactionType { get; set; }

        public Account(int accountId)
        {
            AccountId = accountId;
            StartingBalance = 10000; // Would be populated from persisted data
            Ledger = new TransactionLegder();
        }

        public Transaction.Transaction Deposit(int accountId, decimal amount)
        {
            // TODO: Future state - we will Linq here and persist data by accountId
            this.AccountId = accountId;

            this.OldBalance = StartingBalance;

            Transaction.Transaction transaction = new Transaction.Transaction()
            {
                NewBalance = StartingBalance += amount,
                Success = StartingBalance > OldBalance,
                Amount = amount,
                AccountId = this.AccountId
            };
            TransactionType = transaction.Deposit;
            SuccessfulTransaction = transaction.Success;
            NewBalance = transaction.NewBalance;

            if (Ledger.Transactions == null)
            {
                Ledger.Transactions = new List<Transaction.Transaction>();
            }

            Ledger.Transactions.Add(transaction);
            return transaction;
        }

        public Transaction.Transaction Withdraw(int accountId, decimal amount)
        {
            // TODO: Future state - we will Linq here and persist data by accountId
            this.AccountId = accountId;

            if (amount <= DisplayBalance)
            {
                DisplayBalance -= amount;
            }
            else
            {
                StartingBalance = StartingBalance;
            }

            Transaction.Transaction transaction = new Transaction.Transaction()
            {
                Success = StartingBalance >= amount,
                Amount = amount,
                NewBalance = StartingBalance -= amount,
                AccountId = this.AccountId
            };
            TransactionType = transaction.Withdrawal;
            SuccessfulTransaction = transaction.Success;
            NewBalance = transaction.NewBalance;

            if (Ledger.Transactions == null)
            {
                Ledger.Transactions = new List<Transaction.Transaction>();
            }
            Ledger.Transactions.Add(transaction);

            return transaction;
        }

        public decimal GetCurrentBalanceByAccountId(int accountId)
        {
            // TODO: Future state - we will Linq here and get balance by accountId stored in persisted data
            DisplayBalance = NewBalance != 0 ? NewBalance : StartingBalance;
            return DisplayBalance;
        }

        public List<Transaction.Transaction> GetAllTransactions() // Future state - We will pass an int accountId here as param
        {
            // TODO: Get all transactions by the account Id
            if (Ledger.Transactions != null)
            {
                return Ledger.Transactions.ToList();
            }  
            return new List<Transaction.Transaction>();
        }
    }
}