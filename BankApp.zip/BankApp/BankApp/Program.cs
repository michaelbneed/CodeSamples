﻿using System;

namespace BankApp
{
    public class Program
    {
        private static Account.Account AccountFunctions { get; set; }
        private static decimal transactionAmount = 0;
        private static int accountId;
        private static string transactionConfirmationMessage = String.Empty;

        static Program()
        {
            AccountFunctions = new Account.Account(accountId);
        }
        static void Main(string[] args)
        {
            RunBankingFinancialProgram();
        }

        static void RunBankingFinancialProgram()
        {
            Console.WriteLine("--------------------------------");
            Console.WriteLine("1. Deposit to Checking");
            Console.WriteLine("2. Withdrawal from Checking");
            Console.WriteLine("3. Check Balance");
            Console.WriteLine("4. View Transactions");
            Console.WriteLine("--------------------------------");

            string transactionChoice = Console.ReadLine();

            switch (transactionChoice)
            {
                case "1":
                    Console.WriteLine("Enter Account Number (8 digit Number):");
                    accountId = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter Deposit Amount:");
                    transactionAmount = Convert.ToDecimal(Console.ReadLine());

                    AccountFunctions.Deposit(accountId, transactionAmount);
                    transactionConfirmationMessage = $"Account: {accountId} - Deposit for {transactionAmount} - Success: {AccountFunctions.SuccessfulTransaction.ToString()} - Balance: {AccountFunctions.NewBalance}";

                    Console.WriteLine(transactionConfirmationMessage);
                    Console.WriteLine("Press Enter to Continue...");
                    Console.ReadLine();
                    break;

                case "2":
                    Console.WriteLine("Enter Account Number (8 digit Number):");
                    accountId = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter Withdrawal Amount:");
                    transactionAmount = Convert.ToDecimal(Console.ReadLine());

                    AccountFunctions.Withdraw(accountId, transactionAmount);
                    transactionConfirmationMessage = $"Account: {accountId} - Withdrawal for -{transactionAmount} - Success: {AccountFunctions.SuccessfulTransaction.ToString()} - Balance: {AccountFunctions.NewBalance}";

                    Console.WriteLine(transactionConfirmationMessage);
                    Console.WriteLine("Press Enter to Continue...");
                    Console.ReadLine();
                    break;

                case "3":
                    Console.WriteLine("Enter Account Number (8 digit Number):");
                    accountId = Convert.ToInt32(Console.ReadLine());
                    
                    AccountFunctions.GetCurrentBalanceByAccountId(accountId);
                    transactionConfirmationMessage = $"Current Balance:  {AccountFunctions.DisplayBalance}";

                    Console.WriteLine(transactionConfirmationMessage);
                    Console.WriteLine("Press Enter to Continue...");
                    Console.ReadLine();
                    break;

                case "4":
                    Console.WriteLine("Enter Account Number (8 digit Number):");
                    accountId = Convert.ToInt32(Console.ReadLine());

                    var transactions = AccountFunctions.GetAllTransactions();
                    foreach (var transaction in transactions)
                    {
                        Console.WriteLine($"Account: {transaction.AccountId}, Amount: {transaction.Amount}, Balance: {transaction.NewBalance}, Success: {transaction.Success}");
                    }
                    Console.WriteLine("Press Enter to Continue...");
                    Console.ReadLine();
                    break;
            }

            Console.WriteLine("Perform another Transaction? Y/N");
            string continueProgram = Console.ReadLine()?.ToUpper();
            switch (continueProgram)
            {
                case "Y":
                    RunBankingFinancialProgram();
                    break;
                case "N":
                    break;
            }
        }
    }
}