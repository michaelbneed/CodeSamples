﻿using System.Collections.Generic;

namespace BankApp.Transaction
{
    public class Transaction : TransactionTypes
    {
        public bool Success { get; set; }
        public decimal Amount { get; set; }
        public decimal NewBalance { get; set; }
        public int AccountId { get; set; }
    }

    public class TransactionLegder
    {
        public List<Transaction> Transactions { get; set; }
    }
}