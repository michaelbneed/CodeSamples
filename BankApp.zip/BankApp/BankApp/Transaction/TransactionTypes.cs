﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp.Transaction
{
    public class TransactionTypes
    {
        public string Deposit { get; set; }
        public string Withdrawal { get; set; }
        public string TransferToChecking { get; set; }
        public string TransferToSavings { get; set; }
    }
}