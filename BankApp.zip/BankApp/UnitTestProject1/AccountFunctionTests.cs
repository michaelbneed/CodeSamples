﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankApp;

namespace UnitTests
{
    [TestClass]
    public class AccountFunctionTests
    {
        [TestMethod]
        public void TestDeposit()
        {

        }
    }
}
