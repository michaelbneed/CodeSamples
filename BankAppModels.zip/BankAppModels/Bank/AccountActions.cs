﻿using System;
using System.Collections;

namespace BankAppModels
{
    public class BankAccountActions : BankAccountBase
    {
        // Messages are used to notify transaction results in the unit tests
        Messages messages = new Messages();

        // 'Account Type' class instantiation
        AccountType accType = new AccountType();
        
        public BankAccountActions(string customerName, double balance, string accountType)
        {
            Acc_customerName = customerName;
            Acc_balance = balance;
            Acc_Type = accountType;
        }

        // Accounts' Transactions Methods
        public void Debit(double amount)
        {
            if (amount > Acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterThanBalanceMessage);
            }

            Acc_balance -= amount;
        }

        public void DebitIndividualInvestWithdrawLimit(double amount)
        {
            if (amount > Acc_withdraw_limit && Acc_Type == accType.PrivateInvest || amount > Acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterWithdrawLimitMessage);
            }

            Acc_balance -= amount;
        }

        public void Credit(double amount)
        {
            if (amount <= 0)
            {
                // You can't deposit 0.00 dollars
                throw new ArgumentOutOfRangeException(messages.LessThanZeroMessage);
            }

            Acc_balance += amount;
        }

        public void TransferOut(double amount)
        {
            if (amount > Acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterThanBalanceMessage);
            }

            Acc_balance -= amount;
        }

        public void TransferIn(double amount)
        {
            if (amount <= 0)
            {
                // You can't transfer in 0.00 dollars or less
                throw new ArgumentOutOfRangeException(messages.LessThanZeroMessage);
            }

            Acc_balance += amount;
        }
    }
}