﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace BankAppModels
{
    public class BankAccountBase 
    {
        // Encapsulated fields

        // This is the account owner
        private string acc_customerName;

        // Assign the account balance here
        private double acc_balance;

        // A private variable to hold the account type when passed in
        private string acc_Type;

        // Set WD limit
        private double acc_withdraw_limit = 1000.00;

        // Public properties for each bank account
        public string Acc_customerName { get => acc_customerName; set => acc_customerName = value; }
        public double Acc_balance { get => acc_balance; set => acc_balance = value; }
        public string Acc_Type { get => acc_Type; set => acc_Type = value; }
        public double Acc_withdraw_limit { get => acc_withdraw_limit; set => acc_withdraw_limit = value; }      
    }   
}