﻿using System;
using System.Collections;

namespace BankAppModels
{
    public class BankAccountBase
    {

        // This is the account owner
        public string acc_customerName;

        // Set WD limit
        public const double AccountWithdrawLimit = 1000.00;

        // Assign the account balance here
        public double acc_balance;

        // The account is frozen - future enhancement
        public bool acc_frozen = false;

        // A private variable to hold the account type when passed in
        public string acc_Type;

        public double acc_withdraw_limit = AccountWithdrawLimit;
    }
        
}