﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppModels
{
    public class AccountList
    {
        public string AccountListDetails()
        {
            List<BankAccountBase> accList = new List<BankAccountBase>();
            var result = new StringBuilder();
            var d = ", ";
            foreach (var item in accList)
            {
                string customerName = item.Acc_customerName.ToString();
                string accountBalance = item.Acc_balance.ToString();
                string accountType = item.Acc_Type.ToString();
                string accountWithdrawLimit = item.Acc_withdraw_limit.ToString();

                result.Append(customerName).Append(d).Append(accountBalance).Append(d).Append(accountType).Append(d).Append(accountWithdrawLimit);
            }
            return result.ToString();
        }
    }
}
