﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BankAppModels
{
    public class AccountType 
    {
        public string Checking { get; set; } = "Checking";
        public string CorporateInvest { get; set; } = "Corp Invest";
        public string PrivateInvest { get; set; } = "Private Invest";     
    }

    // Future Enhancement to enumerate account types
    public class AccountTypes : IEnumerable<AccountType>
    {
        List<AccountType> mylist = new List<AccountType>();

        public IEnumerator GetEnumerator()
        {
            return ((IEnumerable<AccountType>)mylist).GetEnumerator();
        }

        IEnumerator<AccountType> IEnumerable<AccountType>.GetEnumerator()
        {
            try
            {
                return mylist.GetEnumerator();
            }
            catch (Exception)
            {
                throw new NotImplementedException();
            }
            
        }

        
    }
}
