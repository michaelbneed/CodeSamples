﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BankAppModels
{
    public class AccountType 
    {
        public string Checking { get; set; } = "Checking";
        public string CorporateInvest { get; set; } = "Corp Invest";
        public string PrivateInvest { get; set; } = "Private Invest";     
    }
}
