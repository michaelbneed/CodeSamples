﻿using System;
using System.Collections;

namespace BankAppModels
{
    public class BankAccount : BankAccountBase
    {
        Messages messages = new Messages();

        // 'Account Type' class instantiation
        AccountType accType = new AccountType();
        
        private BankAccount()
        {
        }

        public BankAccount(string customerName, double balance, string accountType)
        {
            acc_customerName = customerName;
            acc_balance = balance;
            acc_Type = accountType;
        }

        // Accounts' Transactions Methods
        public void Debit(double amount)
        {
            if (acc_frozen)
            {
                throw new Exception();
            }

            if (amount > acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterThanBalanceMessage);
            }

            acc_balance -= amount;
        }

        public void DebitIndividualInvestWithdrawLimit(double amount)
        {
            if (acc_frozen)
            {
                throw new Exception(messages.AccountFrozenMessage);
            }

            if (amount > acc_withdraw_limit && acc_Type == accType.PrivateInvest || amount > acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterWithdrawLimitMessage);
            }

            acc_balance -= amount;
        }

        public void Credit(double amount)
        {
            if (acc_frozen)
            {
                throw new Exception(messages.AccountFrozenMessage);
            }

            if (amount <= 0)
            {
                // You can't deposit 0.00 dollars
                throw new ArgumentOutOfRangeException(messages.LessThanZeroMessage);
            }

            acc_balance += amount;
        }

        public void TransferOut(double amount)
        {
            if (acc_frozen)
            {
                throw new Exception(messages.AccountFrozenMessage);
            }

            if (amount > acc_balance)
            {
                throw new ArgumentOutOfRangeException(messages.DebitGreaterThanBalanceMessage);
            }

            acc_balance -= amount;
        }

        public void TransferIn(double amount)
        {
            if (acc_frozen)
            {
                throw new Exception(messages.AccountFrozenMessage);
            }

            if (amount <= 0)
            {
                // You can't transfer 0.00 dollars
                throw new ArgumentOutOfRangeException(messages.LessThanZeroMessage);
            }

            acc_balance += amount;
        }

        // Future options to lock and unlock the account depending on balances and withdrawals
        private void FreezeAccount()
        {
            acc_frozen = true;
        }

        private void UnfreezeAccount()
        {
            acc_frozen = false;
        }
    }
}