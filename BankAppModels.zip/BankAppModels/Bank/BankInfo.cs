﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAppModels
{
    class bankInfo
    {
        public string bankName = "FakeBank";
        public string bankAddress = "1234 Main St.";
        public string bankCity = "Anywhere";
        public string bankState = "Somewhere";
        public string bankZip = "12345-1111";
        public string bankPhone = "222-222-2222";
        public string bankUrl = "www.myfakebank.com";
    }
}
