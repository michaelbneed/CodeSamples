﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAppModels
{
    public class Messages
    {
        // Messages
        public string DebitGreaterThanBalanceMessage = "Debit amount exceeds balance";
        public string DebitGreaterWithdrawLimitMessage = "Debit amount exceeds limit";
        public string LessThanZeroMessage = "Monetary amount invalid, less than 0.00";
        public string AccountFrozenMessage = "Account is frozen";
        public string TransactionSuccessMessage = "Transaction Successful";
    }
}
