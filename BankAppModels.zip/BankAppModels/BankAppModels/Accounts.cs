﻿using System;
using System.Collections;

namespace BankAppModels
{
    public class BankAccount
        {

            // Messages
            public const string DebitGreaterThanBalanceMessage = "Debit amount exceeds balance";
            public const string DebitGreaterWithdrawLimit = "Debit amount exceeds 1,000.00";
            public const string DebitLessThanZeroMessage = "Debit amount invalid, less than 0.00";
            public const double AccountWithdrawLimit = 1000;
        
            // This is the account owner
            private string acc_customerName;

            // Assign the account balance here
            private double acc_balance;

            // A customer cannot withdraw more than 1000.00
            private double acc_withdraw_limit = AccountWithdrawLimit;

            // The account is frozen if the bank customer tries to overdraft an account
            private bool acc_frozen = false;

            private string acc_Type;
            
            private BankAccount()
            {
            }

            public BankAccount(string customerName, double balance, string accountType)
            {
                acc_customerName = customerName;
                acc_balance = balance;
                acc_Type = accountType;

            // Future Upgrade....
            // Get the list of account types, choose which account type based on user/login in a future UI
            //AccountTypes accTypes = new AccountTypes();
            //foreach (var type in accTypes)
            //    {
            //    accountType = type.ToString();
            //    }
            }

            public string CustomerName
            {
                get { return acc_customerName; }
            }

            public double WithdrawLimit
            {
                get { return acc_withdraw_limit; }
            }

            public string AccountType
            {
                get { return acc_Type; }
            }

            public double Balance
            {
                get { return acc_balance; }
            }

            public void Debit(double amount)
            {
                if (acc_frozen)
                {
                    throw new Exception("Account frozen");
                }

                if (amount > acc_balance)
                {
                    throw new ArgumentOutOfRangeException(DebitGreaterThanBalanceMessage);
                }

                if (amount > acc_withdraw_limit)
                {
                    throw new ArgumentOutOfRangeException(DebitGreaterWithdrawLimit);
                }

                if (amount < 0)
                {
                    throw new ArgumentOutOfRangeException(DebitLessThanZeroMessage);
                }

                acc_balance -= amount; 
            }

            public void Credit(double amount)
            {
                if (acc_frozen)
                {
                    throw new Exception("Account frozen");
                }

                if (amount < 0)
                {
                    throw new ArgumentOutOfRangeException("amount of deposit is not eligible for transaction");
                }

                acc_balance += amount;
            }

            private void FreezeAccount()
            {
                acc_frozen = true;
            }

            private void UnfreezeAccount()
            {
                acc_frozen = false;
            }
    }
    }


