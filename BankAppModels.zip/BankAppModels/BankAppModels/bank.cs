﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAppModels
{
    class bank
    {
        public string bankName;
    }
}
