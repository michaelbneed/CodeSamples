﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankAppModels;

namespace BankAppModelsTest
{
    [TestClass]
    public class UnitTestBankAppModels
    {
        [TestMethod]
        public void Debit_InValidIfDebitGreaterThanBalance()
        {

            double beginningBalance = 10.00;
            double debitAmount = 20.00;
            string accountType = "Checking";
            BankAccount account = new BankAccount("Michael Need", beginningBalance, accountType);

            // act  
            try
            {
                account.Debit(debitAmount);
            }
            catch (ArgumentOutOfRangeException e)
            {
                // assert  
                StringAssert.Contains(e.Message, BankAccount.DebitGreaterThanBalanceMessage);
            }
        }

        [TestMethod]
        public void Credit(double amount)
        {
        }

        [TestMethod]
        public void Transfer(double amount)
        {
        }
    }
}
