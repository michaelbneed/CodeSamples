﻿// VALIDATION UNIT TESTS
// We assert that we will receive the error/notification errors
// This validation failure will result in a successful test
// We are successful since we assert we will receive an error message while enforcing a business rule
// Modify the dollar amount to follow the values in debug with breakpoints
// Change the messages in the assert to see the test fail
// Use breakpoints to test the data, and verify the Try/Catch exception handling
// You will also see the amount sum or subtract based on a successful transaction

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankAppModels;

namespace BankTests
{
    [TestClass]
    public class UnitTestBankAppModels
    {
        AccountType accType = new AccountType();
        Messages messages = new Messages();

        // Test if the withdrawal exceeds the balance
        [TestMethod]
        public void Debit_InValidIfDebitGreaterThanBalance()
        {

            double beginningBalance = 100.00;
            double debitAmount = 200.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.Debit(debitAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.DebitGreaterThanBalanceMessage);
            }
        }

        // Test if the withdrawal exceeds the 1000 dollar limit on an individual investment account
        [TestMethod]
        public void Debit_InValidIfDebitWithdrawalExceedsLimit()
        {

            double beginningBalance = 200.00;
            double debitAmount = 1001.00;
            string accountType = accType.PrivateInvest;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.DebitIndividualInvestWithdrawLimit(debitAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.DebitGreaterWithdrawLimitMessage);
            }
        }

        // Test if user is trying to deposit nothing
        [TestMethod]
        public void Credit_InValidCreditIfLessThanOrEqualZero()
        {
            double beginningBalance = 100.00;
            double creditAmount = 0.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.Credit(creditAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.LessThanZeroMessage);
            }
        }

        // Test if the user is trying to transfer 0 dollars into acccount
        [TestMethod]
        public void Transfer_In_InValidIfIfLessThanOrEqualZero()
        {
            double beginningBalance = 100.00;
            double transferAmount = 0.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.TransferIn(transferAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.LessThanZeroMessage);
            }
        }

        // Test if the user is trying to transfer 0 dollars out of acccount
        [TestMethod]
        public void Transfer_Out_InValid()
        {
            double beginningBalance = 100.00;
            double transferAmount = 200.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.TransferOut(transferAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.DebitGreaterThanBalanceMessage);
            }
        }
    }
}