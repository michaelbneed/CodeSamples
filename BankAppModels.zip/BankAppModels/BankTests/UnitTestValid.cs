﻿// SUCCESS UNIT TESTS
// We assert that we will NOT receive the error/notification errors, but successful transactions
// We are successful since we assert we will receive a success message

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankAppModels;

namespace BankTests
{
    [TestClass]
    public class UnitTestSuccessBankAppModels
    {
        AccountType accType = new AccountType();
        Messages messages = new Messages();

        // Successful withdraw
        [TestMethod]
        public void Debit_Valid()
        {

            double beginningBalance = 100.00;
            double debitAmount = 20.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.Debit(debitAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.TransactionSuccessMessage);
            }
        }

        // Successful deposit
        [TestMethod]
        public void Credit_Valid()
        {
            double beginningBalance = 100.00;
            double creditAmount = 10.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.Credit(creditAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.TransactionSuccessMessage);
            }
        }

        //Successful Xfer in
        [TestMethod]
        public void Transfer_Valid_In()
        {
            double beginningBalance = 100.00;
            double transferAmount = 12.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.TransferIn(transferAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.TransactionSuccessMessage);
            }

        }

        //Successful Xfer out
        [TestMethod]
        public void Transfer_Valid_Out()
        {
            double beginningBalance = 5500.00;
            double transferAmount = 200.00;
            string accountType = accType.Checking;
            BankAccountActions account = new BankAccountActions("Michael Need", beginningBalance, accountType);

            // pass in the amount  
            try
            {
                account.TransferOut(transferAmount);
            }
            catch (Exception e)
            {
                // assert  
                StringAssert.Contains(e.Message, messages.TransactionSuccessMessage);
            }

        }
    }
}