This source code is intended to support the application walkthrough in the book. If you would like to run this code, make sure to at least follow the "Getting Ready" lesson. After that you will be able to follow these steps:

1. Replace the 'src' folder in the project you generated with the 'src' folder in the download
2. Run the 'ionic serve' command

Depending on which application you are trying to run it may or may not work right away. Some applications need to be further configured before they can be used, so make sure to read through the lessons for this application as well.